% The purpose of this code is to introduce multivariable lateral flight control
% design with linear quadratic control methods.
%
% The case used in this code corresponds to John Burken's X29A lateral flight
% control example in his lecture "Fundamentals of Aircraft Flight Control,"
% available on the NASA Engineering and Safety Center, NESC Academy at:
%
% https://nescacademy.nasa.gov/video/0432f4d96ba449d38950f7299a727fdf1d
%
% This code correctly captures the Linear Quadratic Integrator (LQI)
% control architecture, achieves basic tuning to performance specifications,
% and computes multivariable margins. A Nyquist diagram can also be produced
% if the user downloads the nyqlog.m function from Mathworks Exchange, written
% by Trond Andresen.
%
% https://www.mathworks.com/matlabcentral/fileexchange/7444-nyquist-plot-with-logarithmic-amplitudes
%
% While this code captures much of Burken's tests (see minute 40:47 in his
% lecture), there are some notable differences. These include:
%
% 1. Burken's Test Case 2 implements the 4th order actuator models while this
% code implements a reduced order form of the actuator model using only the
% dominant poles of the actuator transfer function.
%
% 2. This script includes singular value robustness analysis with and without
% actuators, comparing the effect of actuators on the tuned controller.
%
% 3. This script is written in Octave and should be compatible with Matlab with
% no modifications necessary.
%
% Written by Ben Dickinson, January 2026
%
% References:
% 1. Lavretsky, E. and Wise, K., "Robust and Adaptive Control with Aerospace
% Applications," 2nd Edition, Springer, 2024. (This script implements the
% procedure outlined in Example 4.10 over pages p230-240, but for a different
% aircraft and control architecture, and lateral flight dynamics)
%
% 2. Bosworth, J.T., "Linearized Aerodynamic and Control Law Models of the
% X-29A Airplane and Comparison with Flight Data," NASA Technical Memorandum
% 4356, February 1992. (The linearized flight dynamic model data in this
% report was digitized using an LLM and put into a function getX29Data, where
% a user can now conveniently access the data in the report for flight control
% studies.)
%
%-------------------------------------------------------------------------------

clear all
close all

% Make a logarithmic Nyquist using the nyqlog.m function. You'll have to have
% this function in your directory. Otherwise, if set to 'on' this script will
% return an error.
plot_Nyquist = 'off';

% Animate simulation
lin_step_resp = 'off';
lin_step_resp_store_frames = 'off';
lin_step_resp_directory = 'visualizations\\closed_loop_step_response\\';
lin_step_resp_make_video = 'off';

% Run high performance tuned controller
final_comparison = 'on';

% Set to 'off' to skip export_to_python.m
do_export_python = 'off';

% Part A - Assess open loop characteristics
%-------------------------------------------------------------------------------

% Load the LTI dynamics (The penalty matrices in this script are specifically
% tuned for Case 3 in getX29Data.m. If the case is changed, retuning of the
% penalties will be necessary.)
sysPlant = getX29Data(3);

% a. Assess rigid body dynamics and identify fast modes that require flight control
oleigLat = eig(sysPlant.Lateral.A)

figure;
plot(real(oleigLat),imag(oleigLat),'*','markersize',16,'linewidth',2); hold on
plot([-10 10],[0 0],'k');
plot([0 0],[-10 10],'k');
xlabel('Re','fontsize',12);
ylabel('Im','fontsize',12);
title({'Open Loop X-29A Lat. Eig.','Mach 0.9, Altitude 8kft'},'fontsize',12);
set(gca,'fontsize',12,'xlim',[-10 10],'ylim',[-10 10]);
grid on
axis equal

% Evaluate metrics
sysLatPlant = ss(sysPlant.Lateral.A, sysPlant.Lateral.B, sysPlant.Lateral.C,...
                 sysPlant.Lateral.D);
[latFreq, latDamp, latPoles] = damp(sysLatPlant);

% Compute time constant of all modes
latTC_sec  = 1./(latFreq.*latDamp);

% Compute time to double (unstable short period and spiral)
latTDD  = log(2)./real(latPoles);

% Part B - Perform an initial test of the controller
%    i.   Extract fast modes from lateral system (i.e. get control design model)
%    ii.  Create the servomechanism design model
%    iii. Determine the LQR control gains and test command tracking
%-------------------------------------------------------------------------------

% i. Extract fast modes from lateral system
A_lat_fast = sysPlant.Lateral.A(1:3,1:3); nA_lat_fast = size(A_lat_fast,1);
B_lat_fast = sysPlant.Lateral.B(1:3,:); nB_lat_fast = size(B_lat_fast,2);
Ct = [1 0 0; 0 1 0];
Dt = [0 0; 0 0];

% ii. Create the robust servomechanism design model
A_RSMD = [zeros(2), Ct; zeros(3,2), A_lat_fast];
B_RSMD = [zeros(2); B_lat_fast];

% iii. Determine the LQR control gains and test command tracking

% Compute LQR gains as an initial test for closed loop tracking. Minimal
% tuning of penalty matrices was applied. The emphasis was penalizing the
% integral error states to enforce tracking.
Q = eye(5); Q(1,1) = 1e5; Q(2,2) = 1e2;
R = eye(2);
Klqr = lqr(A_RSMD, B_RSMD, Q, R);

% Build dynamic controller where states are the integral error dynamics and
% the output equation is the static LQR control law, u = -Kx.
Ac  = zeros(2);
Bc1 = [1 0 0; 0 1 0];
Bc2 = [-1 0; 0 -1];
Cc  = -Klqr(:,1:2);
Dc1 = -Klqr(:,3:5);
Dc2 = zeros(2);

% Define analysis model plant, where where the analysis model is the 4-states
% lateral dynamics, as opposed to the model used for LQR control design, which
% contained three states corresponding the fast rigid body dynamics that
% pertained to flight control design objectives.
Ap = sysPlant.Lateral.A;
Bp = sysPlant.Lateral.B;
Cp = [1 0 0 0; 0 1 0 0; 0 0 1 0];
Dp = zeros(3,2);

% Close the loop with the analysis model
[Acl, Bcl, Ccl, Dcl] = close_loop_1I_to_2I(Ap, Bp, Cp, Dp, Ac, Bc1, Bc2, Cc, Dc1, Dc2);
damp(Acl)

% Integrate closed loop analysis model
dt = 0.01;
t = 0: dt : 14; nt = length(t);
x0 = [0, 0, 0*pi/180, 0*pi/180, 0*pi/180, 0*pi/180];
x = zeros(6,nt); x(:,1) = x0; r_cmd = zeros(2,nt);
for i = 1 : nt-1

  % LQI Lesson - Burken's Sideslip and roll rate command input
  %if t(i) > 10 && t(i) < 13
  %  r_cmd(1,i) = 5*pi/180;
  %elseif t(i) > 13 && t(i) < 16
  %  r_cmd(1,i) = -5*pi/180;
  %end
  %if t(i) > 1 && t(i) < 4
  %  r_cmd(2,i) = 20*pi/180;
  %elseif t(i) > 4 && t(i) < 7
  %  r_cmd(2,i) = -20*pi/180;
  %end

  % RSM Lesson - Roll-rate command (deg/s -> rad/s)
  if t(i) <= 2
      r_cmd(2,i) = 0;

  elseif t(i) <= 3
      % Ramp 0 -> +20 deg/s
      r_cmd(2,i) = ((t(i)-2)/(3-2)) * 20*pi/180;

  elseif t(i) <= 4.5
      % Hold +20 deg/s
      r_cmd(2,i) = 20*pi/180;

  elseif t(i) <= 5.5
      % Ramp +20 -> 0 deg/s
      r_cmd(2,i) = (20 + (t(i)-4.5)/(5.5-4.5)*(0-20)) * pi/180;

  elseif t(i) <= 6.5
      % Hold 0
      r_cmd(2,i) = 0;

  elseif t(i) <= 7.5
      % Ramp 0 -> -20 deg/s
      r_cmd(2,i) = ((t(i)-6.5)/(7.5-6.5)) * (-20*pi/180);

  elseif t(i) <= 9.0
      % Hold -20 deg/s
      r_cmd(2,i) = -20*pi/180;

  elseif t(i) <= 10.0
      % Ramp -20 -> 0 deg/s
      r_cmd(2,i) = (-20 + (t(i)-9.0)/(10.0-9.0)*(20)) * pi/180;

  else
      % Hold 0
      r_cmd(1,i) = 0;
  end

  % No sideslip command for now
  r_cmd(1,i) = 0;

  % Integrate with simple forward Euler
  x(:,i+1) = x(:,i) + dt*(Acl*x(:,i)+Bcl*r_cmd(:,i));

end

% Compute control surface commands
dela_deg = -Klqr(1,:)*x([5,6,1,2,3],:);
delr_deg = -Klqr(2,:)*x([5,6,1,2,3],:);

% Plot the results
figure;
subplot(4,1,1)
plot(t,x(2,:)*180/pi); hold on
plot(t,r_cmd(2,:)*180/pi,'r--');
set(gca,'fontsize',12,'xlim',[0 25],'ylim',[-50 50]);
ylabel('Roll rate [deg/s]','fontsize',12);
title({'Initial Tuning for X-29A Lateral Controller'},'fontsize',12);
grid on

subplot(4,1,2)
plot(t,x(1,:)*180/pi); hold on
plot(t,r_cmd(1,:)*180/pi,'r--');
set(gca,'fontsize',12,'xlim',[0 25],'ylim',[-10 10]);
ylabel('Sideslip [deg]','fontsize',12);
grid on

subplot(4,1,3)
plot(t,x(3,:)*180/pi);
set(gca,'fontsize',12);
ylabel('Yaw rate [deg/s]','fontsize',12);
grid on

subplot(4,1,4)
plot(t,x(4,:)*180/pi);
set(gca,'fontsize',12);
xlabel('Time [sec]','fontsize',12);
ylabel('Bank angle [deg]','fontsize',12);
grid on

% Part C - Test a controller that has undergone further tuning with root locus
% and analysis of control design objectives. Design objectives and analytical
% techniques to tune the controller, or determine adequate penalty matrices
% Q and R, will be covered elsewhere.
%===============================================================================
if strcmp(final_comparison,'on')

% ii. Construct servomechanism design model
A_RSMD = [zeros(2), Ct; zeros(3,2), A_lat_fast];
B_RSMD = [zeros(2); B_lat_fast];

% iii. Compute LQR gains with the tuned Q and R penalty matrices. The basic
% approach involved 1) Tuning integral error penalties separately to achieves
% adequate rise time, and 2) Penalize yaw rate to add damping (i.e.
% "artificial damping") to the sideslip tracking response.
Q(1,1) = 60000;
Q(2,2) = 4000;
Q(3,3) = 0;
Q(4,4) = 0;
Q(5,5) = 2000;

R = eye(2);
Klqr = lqr(A_RSMD, B_RSMD, Q, R);

% Build dynamic controller
Ac  = zeros(2);
Bc1 = [1 0 0; 0 1 0];
Bc2 = [-1 0; 0 -1];
Cc  = -Klqr(:,1:2);
Dc1 = -Klqr(:,3:5);
Dc2 = zeros(2);

% Define analysis model plant
Ap = sysPlant.Lateral.A;
Bp = sysPlant.Lateral.B;
Cp = [1 0 0 0; 0 1 0 0; 0 0 1 0];
Dp = zeros(3,2);

% Close the loop with the analysis model
[Acl, Bcl, Ccl, Dcl] = close_loop_1I_to_2I(Ap, Bp, Cp, Dp, Ac, Bc1, Bc2, Cc, Dc1, Dc2);
damp(Acl)

% Integrate closed loop analysis model
dt = 0.01; tf_sec = 14;
t = 0: dt : tf_sec; nt = length(t);
x0 = zeros(6,1);
x = zeros(6,nt);
x(:,1) = x0;
r_cmd = zeros(2,nt);
for i = 1 : nt-1

  %if t(i) > 10 && t(i) < 13
  %  r_cmd(1,i) = 5*pi/180;
  %elseif t(i) > 13 && t(i) < 16
  %  r_cmd(1,i) = -5*pi/180;
  %end
  %if t(i) > 1 && t(i) < 4
  %  r_cmd(2,i) = 20*pi/180;
  %elseif t(i) > 4 && t(i) < 7
  %  r_cmd(2,i) = -20*pi/180;
  %end

  % RSM Lesson - Roll-rate command (deg/s -> rad/s)
  if t(i) <= 2
      r_cmd(2,i) = 0;

  elseif t(i) <= 3
      % Ramp 0 -> +20 deg/s
      r_cmd(2,i) = ((t(i)-2)/(3-2)) * 20*pi/180;

  elseif t(i) <= 4.5
      % Hold +20 deg/s
      r_cmd(2,i) = 20*pi/180;

  elseif t(i) <= 5.5
      % Ramp +20 -> 0 deg/s
      r_cmd(2,i) = (20 + (t(i)-4.5)/(5.5-4.5)*(0-20)) * pi/180;

  elseif t(i) <= 6.5
      % Hold 0
      r_cmd(2,i) = 0;

  elseif t(i) <= 7.5
      % Ramp 0 -> -20 deg/s
      r_cmd(2,i) = ((t(i)-6.5)/(7.5-6.5)) * (-20*pi/180);

  elseif t(i) <= 9.0
      % Hold -20 deg/s
      r_cmd(2,i) = -20*pi/180;

  elseif t(i) <= 10.0
      % Ramp -20 -> 0 deg/s
      r_cmd(2,i) = (-20 + (t(i)-9.0)/(10.0-9.0)*(20)) * pi/180;

  else
      % Hold 0
      r_cmd(1,i) = 0;
  end

  % No sideslip command for now
  r_cmd(1,i) = 0;

  x(:,i+1) = x(:,i) + dt*(Acl*x(:,i)+Bcl*r_cmd(:,i));

end

% Compute control responses
dela_deg = -Klqr(1,:)*x([5,6,1,2,3],:);
delr_deg = -Klqr(2,:)*x([5,6,1,2,3],:);

% Plot eigenvalues
figure
P = eig(Acl);
plot(real(oleigLat), imag(oleigLat), 'ro', 'markersize',12); hold on
plot(real(P), imag(P), 'k*', 'markersize', 12);
xlabel('Re','fontsize',14);
ylabel('Im','fontsize',14);
title({'Performance-Tuned Closed Loop X-29A Lat. Eig.','Mach 0.9, Altitude 8kft'},'fontsize',14);
set(gca,'fontsize',14,'xlim',[-50 50],'ylim',[-50 50]);
set(gcf,'color','w');
axis equal
grid on

figure('Color','k','Position',[100 100 1.2*550 1.2*425]);

% Colors to match the figure
resp_color = 'y';                 % yellow response
cmd_color  = [0 1 1];             % cyan command
ax_color   = 'w';                 % white axes/text

%-------------------------
% 1) Roll rate
%-------------------------
subplot(4,1,1)
plot(t, x(2,:)*180/pi, 'Color', resp_color, 'LineWidth', 2.5); hold on
plot(t, r_cmd(2,:)*180/pi, '--', 'Color', cmd_color, 'LineWidth', 2.5);
set(gca, ...
    'Color', 'k', ...
    'XColor', ax_color, ...
    'YColor', ax_color, ...
    'GridColor', ax_color, ...
    'GridAlpha', 0.18, ...
    'FontSize', 16, ...
    'LineWidth', 1.0, ...
    'XLim', [0 tf_sec], ...
    'YLim', [-50 50]);
ylabel('Roll rate [deg/s]', 'FontSize', 18, 'Color', ax_color);
grid on

%-------------------------
% 2) Sideslip
%-------------------------
subplot(4,1,2)
plot(t, x(1,:)*180/pi, 'Color', resp_color, 'LineWidth', 2.5); hold on
plot(t, r_cmd(1,:)*180/pi, '--', 'Color', cmd_color, 'LineWidth', 2.5);
set(gca, ...
    'Color', 'k', ...
    'XColor', ax_color, ...
    'YColor', ax_color, ...
    'GridColor', ax_color, ...
    'GridAlpha', 0.18, ...
    'FontSize', 16, ...
    'LineWidth', 1.0, ...
    'XLim', [0 tf_sec], ...
    'YLim', [-10 10]);
ylabel('Sideslip [deg]', 'FontSize', 18, 'Color', ax_color);
grid on

%-------------------------
% 3) Aileron
%-------------------------
subplot(4,1,3)
plot(t, dela_deg, 'Color', resp_color, 'LineWidth', 2.5);
set(gca, ...
    'Color', 'k', ...
    'XColor', ax_color, ...
    'YColor', ax_color, ...
    'GridColor', ax_color, ...
    'GridAlpha', 0.18, ...
    'FontSize', 16, ...
    'LineWidth', 1.0, ...
    'XLim', [0 tf_sec], ...
    'YLim', [-2 2]);
ylabel('Aileron [deg]', 'FontSize', 18, 'Color', ax_color);
grid on

%-------------------------
% 4) Rudder
%-------------------------
subplot(4,1,4)
plot(t, delr_deg, 'Color', resp_color, 'LineWidth', 2.5);
set(gca, ...
    'Color', 'k', ...
    'XColor', ax_color, ...
    'YColor', ax_color, ...
    'GridColor', ax_color, ...
    'GridAlpha', 0.18, ...
    'FontSize', 16, ...
    'LineWidth', 1.0, ...
    'XLim', [0 tf_sec], ...
    'YLim', [-10 10]);
xlabel('Time [sec]', 'FontSize', 20, 'Color', ax_color);
ylabel('Rudder [deg]', 'FontSize', 18, 'Color', ax_color);
grid on

% Optional: manually improve spacing
set(gcf,'InvertHardcopy','off');

% Make video animation of the step response
%-------------------------------------------------------------------------------
fig_step_response = figure('visible', 'on');

% Define custom colors
ax_color = [0 0 0];
fg_color = [1 1 1];
fa_color = [1 1 1];
ft_size  = 16;
sg_color = 'k-';

set(gcf, 'color', fg_color, 'InvertHardCopy', 'off');
iw = 500; ih = 700;
set(gcf, 'Position', [100, 0, 500, 700]);
graphics_toolkit("qt");

% --- Subplot 1: Roll Rate ---
subplot(4,1,1);
h_p     = plot(t(1), x(2,1)*180/pi, sg_color, 'LineWidth', 2.5); hold on;
h_p_cmd = plot(t(1), r_cmd(2,1)*180/pi, 'c--', 'LineWidth', 2.5);
set(gca, 'color', fa_color, 'xcolor', ax_color, 'ycolor', ax_color, ...
         'fontsize', ft_size, 'xlim', [0 tf_sec], 'ylim', [-50 50]);
ylabel('Roll rate [deg/s]', 'fontsize', ft_size, 'color', ax_color);

% --- Subplot 2: Sideslip ---
subplot(4,1,2);
h_beta     = plot(t(1), x(1,1)*180/pi, sg_color, 'LineWidth', 2.5); hold on;
h_beta_cmd = plot(t(1), r_cmd(1,1)*180/pi, 'c--', 'LineWidth', 2.5);
set(gca, 'color', fa_color, 'xcolor', ax_color, 'ycolor', ax_color, ...
         'fontsize', ft_size, 'xlim', [0 tf_sec], 'ylim', [-10 10]);
ylabel('Sideslip [deg]', 'fontsize', ft_size, 'color', ax_color);

% --- Subplot 3: Aileron ---
subplot(4,1,3);
h_dela = plot(t(1), dela_deg(1), sg_color, 'LineWidth', 2.5); hold on;
set(gca, 'color', fa_color, 'xcolor', ax_color, 'ycolor', ax_color, ...
         'fontsize', ft_size, 'xlim', [0 tf_sec], 'ylim', [-2 2]);
ylabel('Aileron [deg]', 'fontsize', ft_size, 'color', ax_color);

% --- Subplot 4: Rudder ---
subplot(4,1,4);
h_delr = plot(t(1), delr_deg(1), sg_color, 'LineWidth', 2.5); hold on;
set(gca, 'color', fa_color, 'xcolor', ax_color, 'ycolor', ax_color, ...
         'fontsize', ft_size, 'xlim', [0 tf_sec], 'ylim', [-10 10]);
xlabel('Time [sec]', 'fontsize', ft_size, 'color', ax_color);
ylabel('Rudder [deg]', 'fontsize', ft_size, 'color', ax_color);

% Check directory existence once before loop
if strcmp(lin_step_resp_store_frames, 'on')
    if ~exist(lin_step_resp_directory, 'dir')
        mkdir(lin_step_resp_directory);
    end
end

% 2. ANIMATION LOOP
for ii = 1 : nt-1

    % Update Data (Grow the lines)
    % We use 1:ii+1 to include the next point
    set(h_p,       'XData', t(1:ii+1), 'YData', x(2,1:ii+1)*180/pi);
    set(h_p_cmd,   'XData', t(1:ii+1), 'YData', r_cmd(2,1:ii+1)*180/pi);

    set(h_beta,    'XData', t(1:ii+1), 'YData', x(1,1:ii+1)*180/pi);
    set(h_beta_cmd,'XData', t(1:ii+1), 'YData', r_cmd(1,1:ii+1)*180/pi);

    set(h_dela,    'XData', t(1:ii+1), 'YData', dela_deg(1:ii+1));
    set(h_delr,    'XData', t(1:ii+1), 'YData', delr_deg(1:ii+1));

    % Only save frame if requested
    if strcmp(lin_step_resp_store_frames, 'on')
        filename = sprintf([lin_step_resp_directory 'Step_Response_%05d.png'], ii);
        print(filename, '-dpng', '-r200');
    else
        drawnow; % Force update screen if not saving
        pause(0.01);
    end

end

if strcmp(lin_step_resp_make_video, 'on')

  fps = 1/dt;

  system(['ffmpeg -framerate ' num2str(fps) ' -i ' ...
          lin_step_resp_directory 'Step_Response_%05d.png ' ...
          '-c:v libx264 -pix_fmt yuv420p ' ...
          '-vf "scale=trunc(iw/2)*2:trunc(ih/2)*2" ' ...
          '-y "' lin_step_resp_directory 'Step_Response.mp4']);

  %system(['ffmpeg -framerate ' num2str(fps) ' -i "' ...
  %        lin_step_resp_directory 'Step_Response_%05d.png" ' ...
  %        '-c:v prores_ks -profile:v 4 -pix_fmt yuva444p10le ' ...
  %        '-vf "scale=trunc(iw/2)*2:trunc(ih/2)*2" ' ...
  %        '-y "' lin_step_resp_directory 'Step_Response_alpha.mov"']);

end

% -------------------------------------------------------------------------
% Export interface for Python / FlightGear visualization (FINAL TUNING ONLY)
% This creates variables expected by export_to_python.m:
%
%   t_sec  : 1xN time vector [sec]
%   x_cl   : 6xN matrix with rows [dela; delr; beta; p; r; phi]
%
% Units expected by export_to_python.m:
%
%   dela, delr, beta, phi in degrees; p, r in deg/s
%
% -------------------------------------------------------------------------
t_sec = t(:).';  % force row vector for consistency
x_cl = zeros(6,nt);
x_cl(1,:) = dela_deg;
x_cl(2,:) = delr_deg;
x_cl(3,:) = x(1,:)*180/pi;   % beta [deg]
x_cl(4,:) = x(2,:)*180/pi;   % p [deg/s]
x_cl(5,:) = x(3,:)*180/pi;   % r [deg/s]
x_cl(6,:) = x(4,:)*180/pi;   % phi [deg]

% Row selectors used by export_to_python.m
sel_dela = 1;
sel_delr = 2;
sel_beta = 3;
sel_p    = 4;
sel_r    = 5;
sel_phi  = 6;

% Run exporter (writes flight_sim_data.mat) if requested and available
if strcmp(do_export_python,'on')
  if exist('export_to_python','file') == 2
    export_to_python;
  else
    warning('export_to_python.m not found on the Octave/MATLAB path. Export skipped.');
  end
end

end

% Part D. Robustness analysis - A 2nd order actuator servo model response is
% extracted from the 4th order actuator models for the aileron and rudder in
% the cited NASA technical report above. These actuator models, when included
% in the loop, will destroy the optimality properties of the LQR gains. These
% properties include the balance of state regulation with minimal control
% effort, and the serendipitious robustness properties of infinite positive
% gain margin, -6 dB or better negative gain margin (particularly for open
% loop unstable systems), and at least 60 degrees of phase margin evaluated
% at the plant input. Even though we realize the optimality properties no longer
% hold, the LQR is an excellent starting point for control design.
%===============================================================================

% 2nd order actuator models used for both the aileron and rudder
w_rps = 71.4;
z     = 0.735;

% Single actuator states
Aa = [         0            1
       -w_rps^2 -2*z*w_rps]; nAa = size(Aa,1);
Ba = [0; w_rps^2]; mBa = size(Ba,2);
Ca = [1 0];

% Combined actuators acting in parallel
Aa_combined = [Aa, zeros(nAa); zeros(nAa), Aa];
Ba_combined = [Ba, zeros(nAa, mBa); zeros(nAa, mBa), Ba];
Ca_combined = [1 0 0 0; 0 0 1 0];

% Define actuator model
actuator = ss(Aa_combined, Ba_combined, Ca_combined, [0 0;0 0]);

% Rigid body dynamics
A_lat = sysPlant.Lateral.A(1:4,1:4); nA_lat = size(A_lat,1);
B_lat = sysPlant.Lateral.B(1:4,:);   nB_lat = size(B_lat,2);
C_lat = [eye(3), zeros(3,1)];
D_lat = zeros(3,2);

lat_rbd = ss(A_lat, B_lat, C_lat, D_lat);

% Determine Plants
plant = lat_rbd*actuator;
plant_wo_act = lat_rbd;

% Part b. Determine dynamic controller with negated output for loop gain
controller = ss(Ac, Bc1, -Cc, -Dc1);

% Part c. Form the determinant of the return difference transfer function
ss_Lu = controller*plant;
phi_ol = poly(ss_Lu.A);
eyeDLu = eye(size(ss_Lu.D));
invIpD = inv(eyeDLu + ss_Lu.D);
phi_cl = poly(ss_Lu.A - ss_Lu.B*invIpD*ss_Lu.C)*det(eyeDLu+ss_Lu.D);
detRD = tf(phi_cl, phi_ol);
detRD = minreal(detRD,1e-4);

ss_Lu_wo_act = controller*plant_wo_act;
phi_ol = poly(ss_Lu_wo_act.A);
eyeDLu = eye(size(ss_Lu_wo_act.D));
invIpD = inv(eyeDLu + ss_Lu_wo_act.D);
phi_cl = poly(ss_Lu_wo_act.A - ss_Lu_wo_act.B*invIpD*ss_Lu_wo_act.C)*det(eyeDLu+ss_Lu_wo_act.D);
detRD_wo_act = tf(phi_cl, phi_ol);
detRD_wo_act = minreal(detRD_wo_act,1e-4);

if strcmp(plot_Nyquist,'on')

  % Part d. Plot nyquist contour without actuator dynamics
  figure;
  nyqlog(detRD_wo_act);

  % Part e. Plot nyquist contour with actuator dynamics
  figure;
  nyqlog(detRD);

end

% Part f. Check cl eigs
[Acl, Bcl, Ccl, Dcl] = close_loop_1I_to_2I(plant.A, plant.B, plant.C, plant.D, Ac, Bc1, Bc2, Cc, Dc1, Dc2);
nAcl = size(Acl,1);

% Plot closed-loop response with actuators just to check
dt = 0.01;
t = 0: dt : 25; nt = length(t);
x0 = zeros(nAcl,1);
x = zeros(nAcl,nt);
x(:,1) = x0;
r_cmd = zeros(2,nt);

for i = 1 : nt-1

  % LQI lecture and corresponds to Burken lecture
  if t(i) > 10 && t(i) < 13
    r_cmd(1,i) = 5*pi/180;
  elseif t(i) > 13 && t(i) < 16
    r_cmd(1,i) = -5*pi/180;
  end
  if t(i) > 1 && t(i) < 4
    r_cmd(2,i) = 20*pi/180;
  elseif t(i) > 4 && t(i) < 7
    r_cmd(2,i) = -20*pi/180;
  end

  % RSM Lesson - Roll-rate command (deg/s -> rad/s)
  if t(i) <= 2
      r_cmd(2,i) = 0;

  elseif t(i) <= 3
      % Ramp 0 -> +20 deg/s
      r_cmd(2,i) = ((t(i)-2)/(3-2)) * 20*pi/180;

  elseif t(i) <= 4.5
      % Hold +20 deg/s
      r_cmd(2,i) = 20*pi/180;

  elseif t(i) <= 5.5
      % Ramp +20 -> 0 deg/s
      r_cmd(2,i) = (20 + (t(i)-4.5)/(5.5-4.5)*(0-20)) * pi/180;

  elseif t(i) <= 6.5
      % Hold 0
      r_cmd(2,i) = 0;

  elseif t(i) <= 7.5
      % Ramp 0 -> -20 deg/s
      r_cmd(2,i) = ((t(i)-6.5)/(7.5-6.5)) * (-20*pi/180);

  elseif t(i) <= 9.0
      % Hold -20 deg/s
      r_cmd(2,i) = -20*pi/180;

  elseif t(i) <= 10.0
      % Ramp -20 -> 0 deg/s
      r_cmd(2,i) = (-20 + (t(i)-9.0)/(10.0-9.0)*(20)) * pi/180;

  else
      % Hold 0
      r_cmd(1,i) = 0;
  end

  % No sideslip command for now
  r_cmd(1,i) = 0;

  x(:,i+1) = x(:,i) + dt*(Acl*x(:,i)+Bcl*r_cmd(:,i));

end

% Plot eigenvalues
figure
P = eig(Acl);
plot(real(oleigLat), imag(oleigLat), 'ro', 'markersize',12); hold on
plot(real(P), imag(P), 'k*', 'markersize', 12);
xlabel('Re','fontsize',14);
ylabel('Im','fontsize',14);
title({'Perf.-Tuned Closed Loop X-29A Lat. Eig. with Act.','Mach 0.9, Altitude 8kft'},'fontsize',14);
set(gca,'fontsize',14,'xlim',[-50 50],'ylim',[-50 50]);
set(gcf,'color','w');
axis equal
grid on

% Closed loop tracking response
figure
subplot(4,1,1)
plot(t,x(2,:)*180/pi); hold on
plot(t,r_cmd(2,:)*180/pi,'r--');
set(gca,'fontsize',12,'xlim',[0 25],'ylim',[-50 50]);
ylabel('Roll rate [deg/s]','fontsize',12);
title({'Perf.-Tuned Closed Loop X-29A Lat. Response with Act.'},'fontsize',12);
grid on

subplot(4,1,2)
plot(t,x(1,:)*180/pi); hold on
plot(t,r_cmd(1,:)*180/pi,'r--');
set(gca,'fontsize',12,'xlim',[0 25],'ylim',[-10 10]);
ylabel('Sideslip [deg]','fontsize',12);
grid on

subplot(4,1,3)
plot(t,x(5,:));
set(gca,'fontsize',12,'xlim',[0 25],'ylim',[-2 2]);
ylabel('Aileron [deg]','fontsize',12);
grid on

subplot(4,1,4)
plot(t,x(7,:));
set(gca,'fontsize',12,'xlim',[0 25],'ylim',[-10 10]);
xlabel('Time [sec]','fontsize',12);
ylabel('Rudder [deg]','fontsize',12);
grid on


% Multivariable stability margin calculations - these are conservative as
% they are derived with singular values. The conservatism comes from the
% singular values finding the worst case direction of a disturbance input
% to the system that leverages cross-channel coupling. A single input system
% does not have this coupling and its singular value is simply the magnitude
% of the scalar signal. Such a result would not suffer from conservatism, but
% also does not capture cross-channel coupling. Therefore the single input
% analysis leads to an overly optimistic stability margin assessment, when
% applied to multi-input system in a sequential manner (i.e. open one channel
% at a time with other channels closed).
%===============================================================================
eye2 = eye(2);
w_rps = logspace(-3, 3, 1000);

% Preallocate
detIpL       = zeros(size(w_rps));
detIpLm1     = zeros(size(w_rps));
minsigIpL    = zeros(size(w_rps));
minsigIpLinv = zeros(size(w_rps));

% Evaluate over frequency range for system with actuators
for ii = 1:numel(w_rps)

    Lu_eval = squeeze(freqresp(ss_Lu, w_rps(ii)));
    rd = eye2 + Lu_eval;
    sr = eye2 + Lu_eval\eye2;

    minsigIpL(ii)    = min(svd(rd));
    minsigIpLinv(ii) = min(svd(sr));

end

% Compute the min(min(singluar values))
min_minsigIpL    = min(minsigIpL);
min_minsigIpLinv = min(minsigIpLinv);

% Compute the singular value stability margins in dB
neg_gm_dB = 20*log10([ (1/(1+min_minsigIpL)) (1-min_minsigIpLinv)]);
pos_gm_dB = 20*log10([ (1/(1-min_minsigIpL)) (1+min_minsigIpLinv)]);
pm_deg    = 180/pi*([2*asin(min_minsigIpL/2), 2*asin(min_minsigIpLinv/2)]);

disp('With Actuators')
fprintf('GM^{-}_{I+L} = %2.2f [dB], GM^{-}_{I+L^{-1}} = %2.2f [dB]\n', neg_gm_dB(1), neg_gm_dB(2));
fprintf('GM^{+}_{I+L} = %2.2f [dB], GM^{+}_{I+L{-1}} = %2.2f [dB]\n', pos_gm_dB(1), pos_gm_dB(2));
fprintf('PM^{+}_{I+L} = %2.2f [deg], PM^{+}_{I+L{-1}} = %2.2f [deg]\n', pm_deg(1), pm_deg(2));

% Plot sigma_S and sigma_T
indx_1 = find(min_minsigIpL==minsigIpL);
indx_2 = find(min_minsigIpLinv==minsigIpLinv);

figure;
semilogx(w_rps, 20*log10(minsigIpL),'b','linewidth',2); hold on
semilogx(w_rps, 20*log10(minsigIpLinv),'r', 'linewidth',2);
semilogx(w_rps(indx_1), 20*log10(minsigIpL(indx_1)),'ob','markersize',12,'linewidth',2);
semilogx(w_rps(indx_2), 20*log10(minsigIpLinv(indx_2)),'or','markersize',12,'linewidth',2);
xlabel('Frequency [rad/s]','fontsize', 12);
ylabel('[dB]','fontsize', 12);
title({'Robustness Bounds with Actuators','(circles are minima used in margin calculations)'},'fontsize',12);
set(gca, 'fontsize',12);
set(gcf,'color','w');
h = legend('\sigma_{min}(I+L) [Return difference, corresponds to multiplicative uncertainty]','\sigma_{min}(I+L^{-1}) [Stability robustness, corresponds to additive uncertainty]');
grid on

% Evaluate stability margins for the system without actuators
%===============================================================================

% Preallocate
detIpL       = zeros(size(w_rps));
detIpLm1     = zeros(size(w_rps));
minsigIpL    = zeros(size(w_rps));
minsigIpLinv = zeros(size(w_rps));

% Evaluate over frequency range for system with actuators
for ii = 1:numel(w_rps)

    Lu_eval = squeeze(freqresp(ss_Lu_wo_act, w_rps(ii)));
    rd = eye2 + Lu_eval;
    sr = eye2 + Lu_eval\eye2;

    minsigIpL(ii)    = min(svd(rd));
    minsigIpLinv(ii) = min(svd(sr));

end

% Compute the min(min(singluar values))
min_minsigIpL    = min(minsigIpL);
min_minsigIpLinv = min(minsigIpLinv);

% Compute the singular value stability margins in dB
neg_gm_dB = 20*log10([ (1/(1+min_minsigIpL)) (1-min_minsigIpLinv)]);
pos_gm_dB = 20*log10([ (1/(1-min_minsigIpL)) (1+min_minsigIpLinv)]);
pm_deg    = 180/pi*([2*asin(min_minsigIpL/2), 2*asin(min_minsigIpLinv/2)]);

disp('No actuators')
fprintf('GM^{-}_{I+L} = %2.2f [dB], GM^{-}_{I+L^{-1}} = %2.2f [dB]\n', neg_gm_dB(1), neg_gm_dB(2));
fprintf('GM^{+}_{I+L} = %2.2f [dB], GM^{+}_{I+L{-1}} = %2.2f [dB]\n', pos_gm_dB(1), pos_gm_dB(2));
fprintf('PM^{+}_{I+L} = %2.2f [deg], PM^{+}_{I+L{-1}} = %2.2f [deg]\n', pm_deg(1), pm_deg(2));

% Plot sigma_S and sigma_T
indx_1 = find(min_minsigIpL==minsigIpL);
indx_2 = find(min_minsigIpLinv==minsigIpLinv);

figure
semilogx(w_rps, 20*log10(minsigIpL),'b','linewidth',2); hold on
semilogx(w_rps, 20*log10(minsigIpLinv),'r', 'linewidth',2);
semilogx(w_rps(indx_1), 20*log10(minsigIpL(indx_1)),'ob','markersize',12,'linewidth',2);
semilogx(w_rps(indx_2), 20*log10(minsigIpLinv(indx_2)),'or','markersize',12,'linewidth',2);
xlabel('Frequency [rad/s]','fontsize', 12);
ylabel('[dB]','fontsize', 12);
title({'Robustness Bounds Without Actuators','(circles are minima used in margin calculations)'},'fontsize',12);
set(gca, 'fontsize',12);
set(gcf,'color','w');
h = legend('\sigma_{min}(I+L) [Return difference, corresponds to multiplicative uncertainty]','\sigma_{min}(I+L^{-1}) [Stability robustness, corresponds to additive uncertainty]');
grid on


