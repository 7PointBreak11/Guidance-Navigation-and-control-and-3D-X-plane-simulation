
% Conversions (set in future)
slug2kg = 1;
ft2m = 1;
slugft22kgm2 = 1;
ftps22mps2 = 1;
slugpft32kgpm3 = 1;

% Geometric properties
S_m2 = 2400*ft2m^2;
b_m  = 130*ft2m;

% Mass
m_kg = 5900*slug2kg;

% Inertial properties
Jxz_kgm2 = 0*slugft22kgm2;
Jzz_kgm2 = 4.2e6*slugft22kgm2;
Jxx_kgm2 = 1.955e6*slugft22kgm2;
Z = Jxx_kgm2*Jzz_kgm2 - Jxz_kgm2^2;

% Aircraft state data
U0_mps = 440*ft2m;
theta0_rad = 0;
Mach = 0.394;

% Atmospheric data
rho_kgpm3 = 0.002378*slugpft32kgpm3;

% Gravity
g_mps2 = 32.2*ftps22mps2;

% Dynamic pressure
qbar_kPa = 1/2*rho_kgpm3*U0_mps^2;

% Reference force and moment
Fref = S_m2*qbar_kPa;
Mref = Fref*b_m;

% Aerodynamic coefficients
Cybeta = -0.6;
Cyp = 0;
Cnbeta = 0.096;
Clbeta = -0.057;
Cnp = -0.0228;
Clp = -0.38;
Cnr = -0.107;
Clr = 0.086;
Cydelr = 0.171;
Cndelr = -0.08;
Cldelr = 0.0131;
Cydela = 0;
Cndela = -0.01;
Cldela = 0.6;

% Compute A-matrix elements
A11 = Cybeta*Fref/(m_kg*U0_mps);
A12 = Cyp*Mref/(2*m_kg*U0_mps^2);
A13 = -1;
A14 = g_mps2/U0_mps*cos(theta0_rad);
A21 = (Mref/Z)*(Jxz_kgm2*Cnbeta + Jzz_kgm2*Clbeta);
A22 = 1/2*Mref*b_m/(Z*U0_mps)*(Jxz_kgm2*Cnp+Jzz_kgm2*Clp);
A23 = 1/2*Mref*b_m/(Z*U0_mps)*(Jxz_kgm2*Cnr+Jzz_kgm2*Clr);
A24 = 0;
A31 = (Mref/Z)*(Jxz_kgm2*Clbeta + Jxx_kgm2*Cnbeta);
A32 = 1/2*Mref*b_m/(Z*U0_mps)*(Jxz_kgm2*Clp+Jxx_kgm2*Cnp);
A33 = 1/2*Mref*b_m/(Z*U0_mps)*(Jxz_kgm2*Clr+Jxx_kgm2*Cnr);
A34 = 0;
A41 = 0;
A42 = 1;
A43 = 0;
A44 = 0;

% Compute B-matrix elements
B11 = Cydela*Fref/(m_kg*U0_mps);
B12 = Cydelr*Fref/(m_kg*U0_mps);
B21 = Mref/Z*(Jxz_kgm2*Cndela + Jzz_kgm2*Cldela);
B22 = Mref/Z*(Jxz_kgm2*Cndelr + Jzz_kgm2*Cldelr);
B31 = Mref/Z*(Jxz_kgm2*Cldela + Jxx_kgm2*Cndela);
B32 = Mref/Z*(Jxz_kgm2*Cldelr + Jxx_kgm2*Cndelr);
B41 = 0;
B42 = 0;

% Build A matrix
A = [ A11, A12, A13, A14;
      A21, A22, A23, A24;
      A31, A32, A33, A34;
      A41, A42, A43, A44];

% Build B matrix
B = [ B11, B12;
      B21, B22;
      B31, B32;
      B41, B42];

% Compute properties of A matrix
damp(A)

% sys_rbd, where rbd is "rigid body dynamics"
sys_rbd.A = A;
sys_rbd.B = B;
sys_rbd.Cybeta = Cybeta;
sys_rbd.S_m2 = S_m2;
sys_rbd.qbar_kPa = qbar_kPa;
sys_rbd.theta0_rad = theta0_rad;
sys_rbd.alpha0_rad = 0;
sys_rbd.U0_mps = U0_mps;
sys_rbd.m_kg = m_kg;
sys_rbd.g_mps2 = g_mps2;

% Save sys_rbd
save designs/sys_rbd.mat sys_rbd -mat
