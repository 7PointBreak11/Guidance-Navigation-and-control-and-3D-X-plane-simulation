% Servomechanism Design Model Examples
%
% Written by B. Dickinson, January 2026
%==========================================================================

clear all
%close all
clc

ex_sel = 'lqi';
%ex_sel = 'rsd_ramp';

%% Define open loop system
%--------------------------------------------------------------------------

% Short Period Model
A_sp = [-0.8757 1; -68.02 0]; n_A_sp = size(A_sp, 1);
B_sp = [-.1531; -74.92];
V_trim_mps = 857;

% Compute Eigenvalues of Short Period Dynamics
sp_eigs = eig(A_sp);

% Create output matrices for alpha and Az
C_alpha = [1, 0];         D_alpha = 0;
C_q     = [0, 1];         D_q     = 0;
C_Az    = [A_sp(1,1)*V_trim_mps, 0]; D_Az = B_sp(1)*V_trim_mps;

%% Investigate properties of the open loop system
%--------------------------------------------------------------------------

% Compute natural frequency and damping of the system
wn_sp_rad = sqrt(real(sp_eigs(1))^2 + imag(sp_eigs(1))^2);
wn_sp_Hz  = wn_sp_rad/(2*pi);
xi_sp     = abs(real(sp_eigs(1)))/wn_sp_rad;

fprintf(['--------------------------------------------------------\n' ...
         'Short Period Approximation\n'])
fprintf('Natural frequency = %2.2f Hz, Damping factor = %2.3f\n', ...
    wn_sp_Hz, xi_sp)
fprintf('--------------------------------------------------------\n')

% Compute step response of alpha and q due to delta_e
sys = ss(A_sp, B_sp, [C_alpha; C_q; C_Az], [D_alpha; D_q; D_Az]);
t = linspace(0, 10, 1e3);
y = step(sys, t);

% Define custom colors
ax_color = [1 1 1];
fg_color = [0 0 0];
fa_color = [0 0 0];
ft_size  = 16;
sg_color = 'y-';

% Plot step response
figure
plot(t, y(:,1), 'linewidth', 2); hold on
plot(t, y(:,2), 'linewidth', 2);
xlabel('Time [s]', 'fontsize', 14);
title('Open Loop Short Period Step Response', 'fontsize', 14);
h = legend('\alpha [rad]', 'q [rad/s]');
set(h,'fontsize',14,'color','k','textcolor','w');
set(gca, 'color', fa_color, 'xcolor', ax_color, 'ycolor', ax_color, ...
         'fontsize', ft_size, 'xlim', [0 5], 'ylim', [-10 7]);
set(gcf, 'color', fg_color, 'InvertHardCopy', 'off');
grid on

if strcmp(ex_sel,'lqi')

%% p = 1: Integral error command tracking
%--------------------------------------------------------------------------

% Extended plant (plant + integral error dynamics)
A_tilde    = [0, C_alpha; [0;0] A_sp]; n_A_tilde  = size(A_tilde, 1);
B_tilde    = [D_alpha; B_sp];
E_tilde    = [0; 1; 1];

% Perturbation to A_sp
A_tilde_ptrb = [0, 0*C_alpha; [0;0] (2*rand(n_A_sp)-1)*norm(A_sp)];
A_tilde = 0*A_tilde_ptrb + A_tilde;

% Compute LQI gains
Q = diag([2*500, 0, 10]);
R = eye(1);
Klqr = lqr(A_tilde, B_tilde, Q, R);

% Check damping ratio of design
damp(A_tilde - B_tilde*Klqr)

% Compute closed-loop state space matrices
A_cl    = A_tilde - B_tilde*Klqr;
B_cmd   = zeros(n_A_tilde, 1); B_cmd(1,1) = -1;
C_cl    = eye(3);
D_cl    = 0;

% Create closed-loop ss object with Az output
sys_cl = ss(A_cl, B_cmd, C_cl, D_cl, ...
    'statename', {'e_I^alpha', 'alpha', 'q'}, ...
    'inputname', {'alpha^{cmd}'}, ...
    'outputname', {'e_I^alpha', 'alpha', 'q'});

% Simulate tracking response to steady input
dt = 1e-3;
t_sec = 0 : dt : 15;

% Initial condition
x_cl0 = [0 0 0];
%x_cl0 = [0 1 0];

% preallocate closed-loop solution with alpha and q state feedback
x_PI_cl = zeros(size(A_tilde,2), length(t_sec));
x_PI_cl(:,1) = x_cl0;
r = zeros(size(t_sec));
w = zeros(size(t_sec));

for i = 1 : length(t_sec) - 1

    % Step, ramp or sinusoid commands
    if t_sec(i+1) < 1
        r(i+1) = 0;
    else
         r(i+1) = 1;
    %     r(i+1) = 0.2*t_sec(i) - 0.2; % ramp
    %     r(i+1) = .2*sin(2*pi*(t_sec(i) - 1)); % sinusoid
    end

    % External disturbance
    if t_sec(i+1) < 1
         w(i+1) = 0;
    else
         w(i+1) = 1;
    %     w(i+1) = t_sec(i) - 1; % ramp
    %     w(i+1) = .2*sin(2*pi*(t_sec(i) - 1)); % sinusoid
    end

   % Trapezoidal rule
    x_PI_cl(:, i+1) = x_PI_cl(:, i) + dt*(A_cl*x_PI_cl(:,i) + B_cmd*r(i) + E_tilde*w(i));
    x_PI_cl(:, i+1) = x_PI_cl(:, i) + dt/2*(A_cl*x_PI_cl(:,i) + B_cmd*r(i) + E_tilde*w(i) + A_cl*x_PI_cl(:,i+1) + B_cmd*r(i+1) + E_tilde*w(i+1));

end

% Define custom colors
ax_color = [1 1 1];
fg_color = [0 0 0];
fa_color = [0 0 0];
ft_size  = 16;
sg_color = 'y-';

figure
plot(t_sec, x_PI_cl(2,:), sg_color, 'linewidth', 2);  hold on
plot(t_sec, r, 'c--', 'linewidth', 2);
xlabel('Time [s]', 'fontsize', ft_size, 'color', ax_color);
ylabel('AoA,\alpha [deg]', 'fontsize', ft_size, 'color', ax_color);
set(gca, 'color', fa_color, 'xcolor', ax_color, 'ycolor', ax_color, ...
         'fontsize', ft_size, 'xlim', [0 5], 'ylim', [-0.2 1.4]);
set(gcf, 'color', fg_color, 'InvertHardCopy', 'off');
h = legend('\alpha','\alpha_{cmd}','\alpha (ramp dist.)');
set(h,'fontsize',14,'color','k','textcolor','w');
grid on

figure
subplot(3,1,1)
plot(t_sec, x_PI_cl(1,:), sg_color, 'linewidth', 2); hold on
ylabel('e_I^{\alpha}', 'fontsize', ft_size, 'color', ax_color);
set(gca, 'color', fa_color, 'xcolor', ax_color, 'ycolor', ax_color, ...
         'fontsize', ft_size, 'xlim', [0 5], 'ylim', [-0.6 0.2]);
set(gcf, 'color', fg_color, 'InvertHardCopy', 'off');
grid on

subplot(3,1,2)
plot(t_sec, x_PI_cl(2,:), sg_color, 'linewidth', 2); hold on
plot(t_sec, r, 'c--', 'linewidth', 2);
ylabel('\alpha [rad]','fontsize', ft_size, 'color', ax_color);
set(gca, 'color', fa_color, 'xcolor', ax_color, 'ycolor', ax_color, ...
         'fontsize', ft_size, 'xlim', [0 5], 'ylim', [-0.2 1.4]);
set(gcf, 'color', fg_color, 'InvertHardCopy', 'off');
grid on

subplot(3,1,3)
plot(t_sec, x_PI_cl(3,:), sg_color, 'linewidth', 2);
xlabel('Time [s]','fontsize', ft_size, 'color', ax_color);
ylabel('q [rad/s]','fontsize', ft_size, 'color', ax_color);
set(gca, 'color', fa_color, 'xcolor', ax_color, 'ycolor', ax_color, ...
         'fontsize', ft_size, 'xlim', [0 5]);
set(gcf, 'color', fg_color, 'InvertHardCopy', 'off');
grid on

elseif strcmp(ex_sel,'rsd_ramp')

%% p = 2: Asymptotic tracking of a ramp input
%--------------------------------------------------------------------------

% Robust servomechanism design model
A_tilde    = [0, 1, 0, 0; 0, 0, C_alpha; zeros(2,2), A_sp];
n_A_tilde  = size(A_tilde, 1);
B_tilde    = [0; D_alpha; B_sp];

% Compute LQI gains (state order de/dt, d^2e/dt^2, \dot{alpha}, \dot{q})
Q = diag([2, 5, 0, .05]);
R = eye(1);
Klqr = lqr(A_tilde, B_tilde, Q, R);

% Define dynamic controller
Ac  = [0 1; 0 0]; n_Ac = size(Ac,1);
Bc1 = [0 0; 1 0];
Bc2 = [0; -1];
Cc  = -[Klqr(1), Klqr(2)];
Dc1 = -[Klqr(3), Klqr(4)];
Dc2 = 0;

% Define state feedback plant output matrix, C
C_sp = [C_alpha; C_q];

% Define closed loop ramp tracking controller
A_cl = [Ac, Bc1*[C_alpha; C_q]; B_sp*Cc, (A_sp + B_sp*Dc1*[C_alpha; C_q])];
B_cl = [Bc2; B_sp*Dc2];
C_cl = [0, 0, C_alpha];
D_cl = 0;

% check eigenvalues of closed loop
damp(A_cl)

% Simulate tracking response to steady input
dt = 1e-3;
t_sec = 0 : dt : 10;

% Initial condition
x_cl0 = [0 0 0 0];

% preallocate closed-loop solution with alpha and q state feedback
x_cl = zeros(size(A_cl,2), length(t_sec));
x_cl(:,1) = x_cl0;
r = zeros(size(t_sec));

for i = 1 : length(t_sec) - 1

    % Open loop response
    x_cl(:, i+1) = x_cl(:, i) + dt*(A_cl*x_cl(:,i) + B_cl*r(i));

%     % series of steps command input
%     if t_sec(i+1) < 1
%         r(i+1) = 0;
%     elseif t_sec(i+1) >= 1 && t_sec(i+1) < 3
%         r(i+1) = 1; % step
%     elseif t_sec(i+1) >= 3 && t_sec(i+1) < 5
%         r(i+1) = 3;
%     elseif t_sec(i+1) >= 5 && t_sec(i+1) < 7
%         r(i+1) = 1;
%     elseif t_sec(i+1) >= 7 && t_sec(i+1) < 9
%         r(i+1) = -1;
%     else
%         r(i+1) = 0;
%     end

    if t_sec(i+1) < 1
        r(i+1) = 0;
    else
%       r(i+1) = 1; % step
%        r(i+1) = t_sec(i) - 1; % ramp
        r(i+1) = .2*sin(2*pi*(t_sec(i) - 1)); % sinusoid
    end

end

% Define custom colors
ax_color = [1 1 1];
fg_color = [0 0 0];
fa_color = [0 0 0];
ft_size  = 16;
sg_color = 'y-';

figure
plot(t_sec, x_cl(3,:), sg_color, 'linewidth', 2); hold on
plot(t_sec, r, 'c--', 'linewidth', 2);
title('Closed-Loop Short Period LQR AoA Tracking','fontsize', 14);
xlabel('Time [s]', 'fontsize', ft_size, 'color', ax_color);
ylabel('AoA,\alpha [deg]', 'fontsize', ft_size, 'color', ax_color);
set(gca, 'color', fa_color, 'xcolor', ax_color, 'ycolor', ax_color, ...
         'fontsize', ft_size, 'xlim', [0 10],'ylim',[-0.3 0.3]);
set(gcf, 'color', fg_color, 'InvertHardCopy', 'off');
h = legend('\alpha','\alpha_{cmd}','\alpha (ramp dist.)');
set(h,'fontsize',14,'color','k','textcolor','w','location','northwest');
grid on

figure
subplot(3,1,1)
plot(t_sec, x_cl(1,:), 'y-', 'linewidth', 2); hold on
plot(t_sec, x_cl(2,:), 'c-', 'linewidth', 2);
ylabel('e_{II}^{\alpha}, e_I^{\alpha}', 'fontsize', ft_size, 'color', ax_color);
xlabel('Time [s]', 'fontsize', ft_size, 'color', ax_color);
set(gca, 'color', fa_color, 'xcolor', ax_color, 'ycolor', ax_color, ...
         'fontsize', ft_size, 'xlim', [0 10], 'ylim', [-10 2]);
set(gcf, 'color', fg_color, 'InvertHardCopy', 'off');
h = legend('e_{II}','e_I');
set(h,'fontsize',14,'color','k','textcolor','w','location','northwest');
grid on

subplot(3,1,2)
plot(t_sec, x_cl(3,:), sg_color, 'linewidth', 2); hold on
plot(t_sec, r, 'c--', 'linewidth', 2);
ylabel('\alpha [rad]','fontsize', 14);
set(gca, 'color', fa_color, 'xcolor', ax_color, 'ycolor', ax_color, ...
         'fontsize', ft_size, 'xlim', [0 10], 'ylim', [-0.5 1.5]);
set(gcf, 'color', fg_color, 'InvertHardCopy', 'off');
grid on

subplot(3,1,3)
plot(t_sec, x_cl(4,:), sg_color, 'linewidth', 2);
xlabel('Time [s]','fontsize', ft_size, 'color', ax_color);
ylabel('q [rad/s]','fontsize', ft_size, 'color', ax_color);
set(gca, 'color', fa_color, 'xcolor', ax_color, 'ycolor', ax_color, ...
         'fontsize', ft_size, 'xlim', [0 10], 'ylim', [0 10]);
set(gcf, 'color', fg_color, 'InvertHardCopy', 'off');
grid on

end
