% export_to_python.m
%
% This script runs the beta-betadot simulation and then processes the
% results into a format suitable for the Python FlightGear visualizer.
% It saves the data to a .mat file.

%-------------------------------------------------------------------------------
% Step 1: Run the simulation to get data in the workspace
%-------------------------------------------------------------------------------

%-------------------------------------------------------------------------------
% Step 2: Define Trim / Initial Conditions for FlightGear
%-------------------------------------------------------------------------------
% These are the assumptions for the visualization's starting point.
% The linear sim is 'about' this point so the _0_ variables corresponds to trimesh
% data as well.
VT_mps      = 152;
alpha_0_rad = 0;
beta_0_rad  = 0;

phi_0_rad   = 0;           % Initial roll angle (rad)
theta_0_rad = alpha_0_rad; % Initial pitch angle (rad) - assuming level flight
psi_0_rad   = 75*pi/180;   % Initial yaw angle (rad)

p_0_rps   = 0;         % Initial roll rate (rad/s)
q_0_rps   = 0;         % Initial pitch rate (rad/s)
r_0_rps   = 0;         % Initial yaw rate (rad/s)

alt_0_ft  = 8500;     % Initial altitude (ft)

% Grand Canyon
lat_0_deg = 36.06;
lon_0_deg = -112.14;

% NYC
%lat_0_deg = 40.69;      % Initial latitude (deg)
%lon_0_deg = -74.044;    % Initial longitude (deg)

% SF
%lat_0_deg = 37.82;      % Initial latitude (deg)
%lon_0_deg = -122.48;    % Initial longitude (deg)

% Conversion factor
deg2rad = pi/180;

%-------------------------------------------------------------------------------
% Step 3: Calculate Total States from Linear Simulation Results
%-------------------------------------------------------------------------------
% The simulation output x_cl is in DEGREES
% We need to convert to RADIANS for FlightGear.
%
% Make pointers to each state
% sel_dela = 1; Not actual input used in sim, not used in plotting use command_input instead, as done below
% sel_delr = 2;
% sel_beta = 3;
% sel_p = 4;
% sel_r = 5;
% sel_phi = 6;
% sel_xc1 = 7;
% sel_xc2 = 8;
%

% Get perturbation states (and convert to rad or rad/s)
delta_phi_rad = x_cl(sel_phi,:) * deg2rad;
delta_p_rps   = x_cl(sel_p,:) * deg2rad;
delta_r_rps   = x_cl(sel_r,:) * deg2rad;

% Calculate total angular orientation
phi_rad   = phi_0_rad + delta_phi_rad;
theta_rad = theta_0_rad * ones(size(t_sec)); % Constant pitch for lat sim
psi_rad   = psi_0_rad + cumtrapz(t_sec, delta_r_rps); % Integrate yaw rate

% Calculate total angular rates
p_rps = p_0_rps + delta_p_rps;
q_rps = q_0_rps * ones(size(t_sec)); % Zero pitch rate for lat sim
r_rps = r_0_rps + delta_r_rps;

% Get control surface deflections
aileron_deg = command_input;
rudder_deg  = x_cl(sel_delr, :);

% --- NEW: Navigation / Position Propagation ---

% 1. Calculate Velocity components (North/East) in m/s
%    V_north = V_total * cos(heading)
%    V_east  = V_total * sin(heading)
vn_mps = VT_mps .* cos(psi_rad);
ve_mps = VT_mps .* sin(psi_rad);

% 2. Integrate Velocity to get Distance Flown (in meters)
dist_north_m = cumtrapz(t_sec, vn_mps);
dist_east_m  = cumtrapz(t_sec, ve_mps);

% 3. Convert Meters to Degrees Lat/Lon
%    Earth Radius ~ 6,371,000 meters
R_earth = 6371000;
delta_lat_rad = dist_north_m / R_earth;
delta_lon_rad = dist_east_m  / (R_earth * cos(lat_0_deg * deg2rad));

% 4. Add change to initial position
latitude_deg  = lat_0_deg + (delta_lat_rad * 180/pi);
longitude_deg = lon_0_deg + (delta_lon_rad * 180/pi);
altitude_ft   = alt_0_ft  * ones(size(t_sec));

%-------------------------------------------------------------------------------
% Step 4: Bundle Data into a Struct for Saving
%-------------------------------------------------------------------------------
flight_data.time_s = t_sec;

% Orientation and Rates
flight_data.phi_rad   = phi_rad;
flight_data.theta_rad = theta_rad;
flight_data.psi_rad   = psi_rad;
flight_data.p_rps   = p_rps;
flight_data.q_rps   = q_rps;
flight_data.r_rps   = r_rps;

% Position
flight_data.altitude_ft   = altitude_ft;
flight_data.latitude_deg  = latitude_deg;
flight_data.longitude_deg = longitude_deg;

% Controls
flight_data.aileron_deg = aileron_deg;
flight_data.rudder_deg  = rudder_deg;

% Other useful data
flight_data.beta_deg    = x_cl(sel_beta, :);
flight_data.VT_mps      = VT_mps * ones(size(t_sec));
flight_data.alpha_0_rad = alpha_0_rad * ones(size(t_sec));

%-------------------------------------------------------------------------------
% Step 5: Save Data to a .mat file
%-------------------------------------------------------------------------------
% We use '-v7' to ensure compatibility with Python's scipy.io.loadmat
output_filename = 'flight_sim_data_Ex2.mat';
save('-v7', output_filename, 'flight_data');

disp(['Flight data successfully saved to: ' output_filename]);
