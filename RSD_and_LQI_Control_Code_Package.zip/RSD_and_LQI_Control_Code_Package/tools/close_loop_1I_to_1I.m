function [Acl, Ccl] = close_loop_1I_to_1I(Ap, Bp, Cp, Dp, Ac, Bc, Cc, Dc);  
                                           
Iu = eye(size(Dc,1));

Z = Iu - Dc*Dp;
Zinv = Z\Iu;

Acl = [ Ap + Bp*Zinv*Dc*Cp,         Bp*Zinv*Cc;  ...
        Bc*Cp + Bc*Dp*Zinv*Dc*Cp, Ac + Bc*Dp*Zinv*Cc];

Ccl = [ Cp + Dp*Zinv*Dc*Cp, Dp*Zinv*Cc ];
