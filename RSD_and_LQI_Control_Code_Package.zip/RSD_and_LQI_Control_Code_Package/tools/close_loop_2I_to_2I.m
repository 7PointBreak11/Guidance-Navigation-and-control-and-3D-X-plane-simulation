function [Acl, Bcl, Ccl, Dcl] = close_loop_2I_to_2I( ...
                                  Ap, Bp1, Bp2, Cp, Dp1, Dp2, ...
                                  Ac, Bc1, Bc2, Cc, Dc1, Dc2);                                         

Iu = eye(size(Dc1,1));

Z = Iu - Dc1*Dp1;
Zinv = Z\Iu;

Acl = [ Ap + Bp1*Zinv*Dc1*Cp,         Bp1*Zinv*Cc;  ...
        Bc1*Cp + Bc1*Dp1*Zinv*Dc1*Cp, Ac + Bc1*Dp1*Zinv*Cc];

Bcl = [ Bp2 + Bp1*Zinv*Dc1*Dp2, Bp1*Zinv*Dc2; ...
        Bc1*(Dp2+Dp1*Zinv*Dc1*Dp2), Bc1*Dp1*Zinv*Dc2 + Bc2];

Ccl = [ Cp + Dp1*Zinv*Dc1*Cp, Dp1*Zinv*Cc ];

Dcl = [ Dp2 + Dp1*Zinv*Dc1*Dp2,  Dp1*Zinv*Dc2];                                          