% FUNCTION siso_bode.m computes the frequency response of an LTI system and
% plots the results. While there is already body plot functionality in Matlab, 
% this offers more transparency into the process of creating the plot, and 
% allows direct adjustment of plot appearance. This script is only for SISO
% LTI systems.
%
% Input
%   A     - SISO LTI system A matrix
%   B     - SISO LTI system B matrix
%   C     - SISO LTI system C matrix
%   D     - SISO LTI system D matrix
%   w_rps - frequency vector in radians per second for evaluation of the Bode 
%           plot
%
% Output
%   H_Mag   - Magnitude of response
%   H_Phase - Phase angle of response
%   H       - Frequency response
%
% History: Written by B. Dickinson, June 2022.
%-------------------------------------------------------------------------------
function [H_Mag_dB, H_Phase_deg, H] = siso_bode(A, B, C, D, w_rps)
  
nw = length(w_rps);
nA = size(A,1);

H_Mag_dB   = zeros(1,nw);
H_Phase_deg = H_Mag_dB;
H = H_Mag_dB;
eyeA    = eye(nA);
for i = 1 : nw
  
  sImAinv = (1i*w_rps(i)*eyeA - A)\eyeA;
  H(i)       = C*sImAinv*B + D;
  
  H_Mag_dB(i)    = 20*log10( sqrt( real(H(i)).^2 + imag(H(i)).^2 ) );
  H_Phase_deg(i) = 180/pi*atan2(imag(H(i)), real(H(i)));
  
end

if ~exist('siso_bode_mag_plot','var')
  siso_bode_mag_plot = figure;
elseif ~isgraphics(siso_bode_mag_plot)
  siso_bode_mag_plot = figure;
end

figure(siso_bode_mag_plot)
semilogx(w_rps./6.28, H_Mag_dB, 'c', 'linewidth', 3); hold on;
xlabel('Frequency [Hz]', 'fontsize', 16, 'color', 'y');
ylabel('Magnitude [dB]', 'fontsize', 16, 'color', 'y');
set(gcf,'color','k','position',[1145 631 560 230])
set(gca,'color','k','fontsize',16,'gridcolor','y','xcolor','y','ycolor','y');
set(gca,'position',[0.13 0.22 0.78 0.70]);
set(gcf,'InvertHardCopy','off'); 
box off 
grid on
shg
  
if ~exist('siso_bode_phase_plot','var')
  siso_bode_phase_plot = figure;
elseif ~isgraphics(siso_bode_mag_plot)
  siso_bode_phase_plot = figure;
end

figure(siso_bode_phase_plot)
semilogx(w_rps./6.28, H_Phase_deg, 'c', 'linewidth', 3); hold on;
xlabel('Frequency [Hz]', 'fontsize', 16, 'color', 'y');
ylabel('Phase Angle [deg]', 'fontsize', 16, 'color', 'y');
set(gcf,'color','k','position',[1145 269 560 230])
set(gca,'color','k','fontsize',16,'gridcolor','y','xcolor','y','ycolor','y');
set(gca,'position',[0.13 0.22 0.78 0.70]);
set(gcf,'InvertHardCopy','off');  
grid on
box off
shg
  