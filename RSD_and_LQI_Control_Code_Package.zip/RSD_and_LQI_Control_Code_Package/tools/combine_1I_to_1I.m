% FUNCTION combine_1I_to_1I.m combines two LTI systems into a single system. 
% No input or output channels are connected in series or fedback. Instead, this 
% is simply combining the two systems into a single system in a decoupled
% manner that is a single LTI system.
%
%-------------------------------------------------------------------------------
function [A, B, C, D] = combine_1I_to_1I(A1, B1, C1, D1, A2, B2, C2, D2)

[nA1,mA1]   = size(A1);
[nB1,mB1]   = size(B1);
[nC1,mC1]   = size(C1);
[nD1,mD1]   = size(D1);
[nA2,mA2]   = size(A2);
[nB2,mB2]   = size(B2);
[nC2,mC2]   = size(C2);
[nD2,mD2]   = size(D2);
  
A = [A1, zeros(nA1, mA2); zeros(nA2, mA1), A2];
B = [B1, zeros(nB1, mB2); zeros(nB2, mB1), B2];
C = [C1,  zeros(nC1, mC2); zeros(nC2, mC1), C2];
D = [D1,  zeros(nD1, mD2); zeros(nD2, mD1), D2];
