function gsframe(K, sdir, fname, axislims, framesel, vidsel, gsfig)

  for ii = [1, 1 : length(K)]

    if ii == 1
      plot([axislims(1) axislims(2)],[0 0], 'linewidth', 1, 'color',[255,255,102]./256); hold on
    end
    h = plot(K(ii),0,'wx','markersize',18,'linewidth',2);

    set(gca,'xlim',[axislims(1) axislims(2)], ...
        'ylim', [axislims(3) axislims(4)],'color','k', ...
        'gridcolor','k', 'fontsize', 16, 'fontweight', 'bold', ...
        'xaxislocation','origin', 'yaxislocation', 'origin', ...
        'xcolor',[255,255,102]./256, 'ycolor','k');
    set(gcf,'color','k');
    set(gcf,'InvertHardCopy','off')

    % Add xticklabels manually to ensure 0 is included
    xticks = get(gca, 'xtick');
    xticklabels = arrayfun(@(x) sprintf('%g', x), xticks, 'UniformOutput', ...
                           false);
    set(gca, 'xticklabel', xticklabels);

    xlabel('Gain, K_{Ir}','fontsize',20,'color',[255,255,102]./256);

    grid off
    axis equal
    box off
    pause(.05)
    drawnow
    shg

    if strcmp(framesel, 'on')

      if ii == 1
        if ~exist([sdir],'dir')
          mkdir([sdir])
        endif
      endif

      filename=sprintf([sdir fname '_%05d.jpg'], ii);
      print(filename);

    end

    delete(h)

  end
