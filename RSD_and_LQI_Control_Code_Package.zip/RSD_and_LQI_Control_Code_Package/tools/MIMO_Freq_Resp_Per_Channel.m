function L_k = MIMO_Freq_Resp_Per_Channel(L)

% Compute SISO Freq Resp for each channel with respective remaining
% channels closed
%--------------------------------------------------------------------------
mp = size(L.c,1);

% Preallocate structure
if mp > 1

    for k = 1 : mp

        % Returns data of k and 1:mp that is not in their intersection
        idx_closed = setxor(k, 1 : mp);

        % Feedback closed channels
        L_k = feedback(L, eye(mp-1), idx_closed, idx_closed);

    end

end
