function rlframe(Acl, idx, sdir, fname, axislims, framesel, vidsel, rlfig)

% Get eigenvalues
[~, zeta, P] = damp(Acl);

set(0, 'defaultfigurevisible', 'off');

linespec = 'w.';

% Plot rool locus point
plot(real(P), imag(P), linespec, 'markersize', 8);

set(gca,'xlim',axislims(1:2), 'ylim', axislims(3:4),'color','k', ...
    'gridcolor',[0.9961 0.9961 0.3984], 'fontsize', 16, ...
    'fontweight', 'bold', 'xcolor',[0.56, 0.55, 0.055], ...
    'ycolor', [0.56, 0.55, 0.055]);
set(gcf,'color','k');
set(gcf,'InvertHardCopy','off')

xlabel('Real Axis','fontsize',14, 'color', [0.9961 0.9961 0.3984]);
ylabel('Imaginary Axis','fontsize',14, 'color', [0.9961 0.9961 0.3984]);

grid on
%axis equal
box off
pause(.01)
drawnow

% Plot acceptable zone
%zetamin = 0.6; thetamin = asin(zetamin);
%zetamax = 1.0; thetamax = asin(zetamax);
%wnmin = 2;
%wnmax = 6;
%theta = linspace(thetamin, thetamax, 100);
%wn = linspace(wnmin, wnmax, 100);
%
%segment1x = -wnmax*sin(theta);
%segment1y = wnmax*cos(theta);
%segment2x = -wn*sin(thetamin);
%segment2y = wn*cos(thetamin);
%segment3x = -wnmin*sin(theta);
%segment3y = wnmin*cos(theta);
%segment4x = -wn*sin(thetamax);
%segment4y = wn*cos(thetamax);
%
%plot(segment1x, segment1y,'c--','linewidth',2); hold on
%plot(segment2x, segment2y,'c--','linewidth',2);
%plot(segment3x, segment3y,'c--','linewidth',2);
%plot(segment4x, segment4y,'c--','linewidth',2);

if strcmp(framesel, 'on')

  if idx == 1
    if ~exist([sdir],'dir')
      mkdir([sdir])
    endif
  endif

  filename=sprintf([sdir fname '_%05d.jpg'], idx);
  print(filename);

end


