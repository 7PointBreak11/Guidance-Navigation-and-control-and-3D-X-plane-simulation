% FUNCTION mimo_margins.m computes the multivariable singular value stability
% margins for additive and multiplicative disturbances. Margins are printed.
%
% Inputs:
%    sys - A state space object of the loop gain transfer function
%
% Outputs:
%    GMmult - The multiplicative disturbance gain margins in dB
%    PMmult - The multiplicative disturbance phase margins in deg
%    GMadd  - The additive disturbance gain margins in dB
%    PMadd  - The additive disturbance phase margins in deg
%
% History:
%    Written by B. Dickinson Oct 2025.
%-------------------------------------------------------------------------------
function mimo_margins(sys)

  % Obtain loop gain matrices
  A_Lu = sys.A;
  B_Lu = sys.B;
  C_Lu = sys.C;
  D_Lu = sys.D;

  % Create frequency vector
  w_rps = logspace(-3, 3, 500); nw_rps = length(w_rps);

  % Identity matrices
  nA_Lu = size(A_Lu,1);
  mB_Lu = size(B_Lu,2);
  eye_nA_Lu = eye(nA_Lu);
  eye_mB_Lu = eye(mB_Lu);

  % Preallocate
  detIpLm1 = zeros(size(w_rps));
  MinSigRD = zeros(size(w_rps));
  MinSigSR = zeros(size(w_rps));

  % Loop through frequency vector and compute frequency domain metrics
  for i = 1 : nw_rps

      % Compute resolvent for loop gain at the input
      sImAinv = (1i*w_rps(i)*eye_nA_Lu - A_Lu)\eye_nA_Lu;

      % Compute loop gain at input
      Lu_eval = C_Lu*sImAinv*B_Lu + D_Lu;

      % Determinant of return difference plus negative 1
      detIpLm1(i) = -1 + det(eye_mB_Lu + Lu_eval);

      % Compute return difference
      RD = eye_mB_Lu + Lu_eval;

      % Get non-zero singular values (1e-10 threshold)
      svdRD = svd(RD);
      svdRD = svdRD(svdRD > 1e-10);

      % minimum singular value of return difference
      MinSigRD(i) = min(svdRD);

      % Compute stability robustness
      SR = Lu_eval\(eye_mB_Lu + Lu_eval);

      % Grab non-zero singular values (1e-10 threshold)
      svdSR = svd(SR);
      svdSR = svdSR(svdSR > 1e-10);

      % minimum singular value of stability robustness
      MinSigSR(i) = min(svdSR);

  end

  % Compute multivariable stability margins
  sigma_S = min(MinSigRD);  asindx = find(sigma_S == MinSigRD);
  sigma_T = min(MinSigSR);  bsindx = find(sigma_T == MinSigSR);

  % Compute and print stability margins
  GMIpLu_dB     = 20*log10([1/(1+sigma_S), 1/(1-sigma_S)]);
  GMIpLuinv_dB  = 20*log10([1-sigma_T, 1+sigma_T]);
  PMIpLu_deg    = [-2*asin(sigma_S/2),2*asin(sigma_S/2)]*180/pi;
  PMIpLuinv_deg = [-2*asin(sigma_T/2),2*asin(sigma_T/2)]*180/pi;

  fprintf('\nMax I+L^-1 Margins (Additive Dist.): [%2.2f dB %2.2f dB]\n', GMIpLuinv_dB(1), ...
     GMIpLuinv_dB(2));
  fprintf('\nMax I+L Margins (Mult. Dist.): [%2.2f dB %2.2f dB]\n', GMIpLu_dB(1), ...
     GMIpLu_dB(2));

  fprintf('\nMax Phase Margins (Additive Dist.): [%2.2f deg %2.2f deg]\n', PMIpLuinv_deg(1), ...
     PMIpLuinv_deg(2));
  fprintf('\nMax Phase Margins (Mult. Dist.): [%2.2f deg %2.2f deg]\n', PMIpLu_deg(1), ...
     PMIpLu_deg(2));
