function nyqframe(A_lu, b_lu, c_lu, d_lu, idx, sdir, fname, axislims, ...
                  framesel, vidsel, nyqfig)

%% Set up frequency vector (this avoids a pole at the origin as required)
nyquist_radius = 1e-4;
nyquist_radius2 = 1e2;
w_5_rps = nyquist_radius*(cos((-pi/2+1e-3):0.001:-1e-3) + 1i*sin((-pi/2+1e-3):0.001:-1e-3));
w_4_rps = -logspace(log10(nyquist_radius2), log10(nyquist_radius), 1000)*1i;
w_3_rps = nyquist_radius2*(cos((pi/2-1e-3):-0.001:(-pi/2+1e-3)) + 1i*sin((pi/2-1e-3):-0.001:(-pi/2+1e-3)));
w_2_rps = logspace(log10(nyquist_radius), log10(nyquist_radius2), 1000)*1i;
w_1_rps = nyquist_radius*(cos(1e-3:0.001:(pi/2-1e-3)) + 1i*sin(1e-3:0.001:(pi/2-1e-3)));

w_rps = [w_1_rps, w_2_rps, w_3_rps, w_4_rps, w_5_rps];
w_rps = 1i*logspace(-4, 4, 1000);
nw_rps = length(w_rps);

% Preallocate Lu
Lu = zeros(1, nw_rps);

% Identity
nA_lu  = size(A_lu,1);
I_nAlu = eye(nA_lu);

% Compute loop gain frequency response
for jj = 1 : nw_rps
  Lu(jj) = c_lu*(( w_rps(jj)*I_nAlu - A_lu )\I_nAlu)*b_lu + d_lu;
end

if idx == 1
  figure(nyqfig)
  plot([axislims(1) axislims(2)],[0 0],'w'); hold on
  plot([0 0], [axislims(3) axislims(4)], 'w');
  plot(-1,0,'r.','markersize',18);
  theta = -6.28 : 0.01 : 6.28;
  plot(cos(theta)-1, sin(theta), 'c--');
  pause(0.01);
end

figure(nyqfig)
h1 = plot(real(Lu), imag(Lu), 'c', 'linewidth', 1.5);

set(gca,'xlim',[axislims(1) axislims(2)], 'ylim', [axislims(3) axislims(4)], ...
    'color','k', 'gridcolor',[0.9961 0.9961 0.3984], 'fontsize', 16, ...
    'fontweight', 'bold', 'xcolor',[0.9961 0.9961 0.3984], ...
    'ycolor', [0.9961 0.9961 0.3984]);
set(gcf,'color','k');
set(gcf,'InvertHardCopy','off')

axis equal
grid on
pause(.1)
drawnow

if strcmp(framesel, 'on')
    filename=sprintf([sdir fname '_%05d.jpg'], idx);
    print(filename);
end

delete(h1)

