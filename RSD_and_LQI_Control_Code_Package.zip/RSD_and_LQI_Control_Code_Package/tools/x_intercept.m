function x_int = x_intercept(y,x)
% find the value where the data crosses the horizontal axis (x-axis)
n=prod(size(y));
j=0;
i=0;

while j < n,
  if y(n-j) > 0.,
    i=n-j;
    j=n+1;
  end;
  j=j+1;
end

% Index out of bounds check
if (i) < 1
    % Return 0 if out of bounds
    x1 = 0;
    return
end

pp=inv([x(i) 1.;x(i+1) 1.])*[y(i);y(i+1)];
x_int=-pp(2)/pp(1);
