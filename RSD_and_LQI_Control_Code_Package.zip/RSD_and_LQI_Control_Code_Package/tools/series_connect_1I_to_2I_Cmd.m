% FUNCTION SERIES_CONNECT.m connects two state space LTI systems in series. 
% The connection is such that system 1 is connected to the input of system 2.
% The input to the connected system is the input to system 1, and
% the output of the connected system is the output of system 2.
%
%-------------------------------------------------------------------------------
function [As, Bs1, Bs2, Cs, Ds1, Ds2] = series_connect_1I_to_2I_Cmd( ...
                                    A1, B1, C1, D1, A2, B21, B22, C2, D21, D22)

[nA1,mA1]   = size(A1);
[nB1,mB1]   = size(B1);
[nC1,mC1]   = size(C1);
[nD1,mD1]   = size(D1);
[nA2,mA2]   = size(A2);
[nB21,mB21] = size(B21);
[nB22,mB22] = size(B22);
[nC2,mC2]   = size(C2);
[nD21,mD21] = size(D21);
[nD22,mD22] = size(D22);
  
As  = [A1, zeros(nA1,nA2); B22*C1, A2];
Bs1 = [zeros(nA1,mB21); B21];
Bs2 = [B1; B22*D1];
Cs  = [D22*C1, C2];
Ds1 = [D21];
Ds2 = D22*D1;