% FUNCTION SERIES_CONNECT.m connects two state space LTI systems in series. 
% The connection is such that system 1 is connected to the input of system 2.
% The input to the connected system is the input to system 1, and
% the output of the connected system is the output of system 2.
%
%-------------------------------------------------------------------------------
function [As, Bs, Cs, Ds] = series_connect_1I_to_1I(A1, B1, C1, D1, A2, B2, ...
                                                                        C2, D2)

[nA1,mA1]   = size(A1);
[nB1,mB1]   = size(B1);
[nC1,mC1]   = size(C1);
[nD1,mD1]   = size(D1);
[nA2,mA2]   = size(A2);
[nB2,mB2]   = size(B2);
[nC2,mC2]   = size(C2);
[nD2,mD2]   = size(D2);
  
As = [A1, zeros(nA1,nA2); B2*C1, A2];
Bs = [B1; B2*D1];
Cs = [D2*C1, C2];
Ds =  D2*D1;