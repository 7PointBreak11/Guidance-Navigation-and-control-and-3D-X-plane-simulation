% double checked 11/3/23
% checked again 11/4/23

function [Acl, Bcl, Ccl, Dcl] = close_loop_2I_to_1I( ...
                                  Ap, Bp1, Bp2, Cp, Dp1, Dp2, ...
                                  Ac, Bc, Cc, Dc);                                         

Iu = eye(size(Dc,1));

Z = Iu - Dc*Dp1;
Zinv = Z\Iu;

nBp1 = size(Bp1,1);
mCc  = size(Cc,2);

Acl = [ Ap + Bp1*Zinv*Dc*Cp, Bp1*Zinv*Cc;  ...
        Bc*(Iu + Dp1*Zinv*Dc)*Cp, Ac + Bc*Dp1*Zinv*Cc];

Bcl = [ Bp2 + Bp1*Zinv*Dc*Dp2; ...
        Bc*(Dp2+Dp1*Zinv*Dc*Dp2)];

Ccl = [ Cp + Dp1*Zinv*Dc*Cp, Dp1*Zinv*Cc ];

Dcl = [ Dp2 + Dp1*Zinv*Dc*Dp2];                                          