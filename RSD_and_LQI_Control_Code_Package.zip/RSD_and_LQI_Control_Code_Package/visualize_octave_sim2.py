import time
import socket # We use standard socket, not flightgear_python for this part
import numpy as np
import scipy.io
from flightgear_python.fg_if import FDMConnection

def fdm_callback(fdm_data, event_pipe):
    if event_pipe.child_poll():
        fdm_tuple = event_pipe.child_recv()
        (alt_m_child, phi_rad_child, theta_rad_child, psi_rad_child,
         u_b_ftps_child, v_b_ftps_child, w_b_ftps_child, alpha_rad_child,
         beta_rad_child, lat_rad_child, long_rad_child,
         v_north_ft_per_s_parent, v_east_ft_per_s_parent, v_down_ft_per_s_parent) = fdm_tuple

        fdm_data['alt_m'] = alt_m_child
        fdm_data['phi_rad'] = phi_rad_child
        fdm_data['theta_rad'] = theta_rad_child
        fdm_data['psi_rad'] = psi_rad_child
        fdm_data['v_body_u'] = u_b_ftps_child
        fdm_data['v_body_v'] = v_b_ftps_child
        fdm_data['v_body_w'] = w_b_ftps_child
        fdm_data['alpha_rad'] = alpha_rad_child
        fdm_data['beta_rad'] = beta_rad_child
        fdm_data['lat_rad'] = lat_rad_child
        fdm_data['lon_rad'] = long_rad_child
        fdm_data['v_north_ft_per_s'] = v_north_ft_per_s_parent
        fdm_data['v_east_ft_per_s']  = v_east_ft_per_s_parent
        fdm_data['v_down_ft_per_s']  = v_down_ft_per_s_parent
        
    return fdm_data  

if __name__ == '__main__':
    
    # 1. Setup FDM Connection (Physics)
    fdm_conn = FDMConnection()
    fdm_event_pipe = fdm_conn.connect_rx('localhost', 5501, fdm_callback)
    fdm_conn.connect_tx('localhost', 5502)
    
    # 2. Setup UDP Socket (Controls)
    # This is "fire and forget" 
    controls_sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    controls_addr = ('localhost', 5505)
    controls_addr = ('127.0.0.1', 5505)

    fdm_conn.start()
    
    # Get flight simulation data (There are multiple simulation data files)
    print("Loading flight data from flight_sim_data.mat...")
    mat_data = scipy.io.loadmat('flight_sim_data.mat')
    
    #print("Loading flight data from flight_sim_data_Kp_off.mat...")
    #mat_data = scipy.io.loadmat('flight_sim_data_Kp_off.mat')
    
    flight_data = mat_data['flight_data'][0, 0]
    t_s = flight_data['time_s'].flatten()
    nt_s = len(t_s)
    
    # Constants
    DEG_TO_RAD = np.pi / 180.0
    M_TO_FT = 3.28084
    MAX_AIL_DEF_DEG = 1.0#2.0
    MAX_RUD_DEF_DEG = 1.0#2.0
    MAX_ELE_DEF_DEG = 20.0
    MAX_AIL_DEF_RAD = MAX_AIL_DEF_DEG * DEG_TO_RAD
    MAX_RUD_DEF_RAD = MAX_RUD_DEF_DEG * DEG_TO_RAD
    MAX_ELE_DEF_RAD = MAX_ELE_DEF_DEG * DEG_TO_RAD

    dela_rad = flight_data['aileron_deg'].flatten() * DEG_TO_RAD
    delr_rad = flight_data['rudder_deg'].flatten() * DEG_TO_RAD
    dele_rad = np.zeros_like(t_s)
    
    dela_norm = np.clip(dela_rad / MAX_AIL_DEF_RAD, -1.0, 1.0)
    dele_norm = np.clip(dele_rad / MAX_ELE_DEF_RAD, -1.0, 1.0)
    delr_norm = np.clip(delr_rad / MAX_RUD_DEF_RAD, -1.0, 1.0)
    
    # Other data
    phi_rad = flight_data['phi_rad'].flatten()
    theta_rad = flight_data['theta_rad'].flatten()
    psi_rad = flight_data['psi_rad'].flatten()
    alt_m = flight_data['altitude_ft'].flatten() / M_TO_FT
    lat_rad = flight_data['latitude_deg'].flatten() * DEG_TO_RAD
    lon_rad = flight_data['longitude_deg'].flatten() * DEG_TO_RAD
    VT_mps = flight_data['VT_mps'].flatten()[0]
    VT_ftps = VT_mps * M_TO_FT
    alpha_0_rad = flight_data['alpha_0_rad'].flatten()[0] 
    beta_rad = flight_data['beta_deg'].flatten() * DEG_TO_RAD
    alpha_rad = np.full_like(t_s, alpha_0_rad)
    v_body_u_ftps = VT_ftps * np.cos(alpha_rad) * np.cos(beta_rad)
    v_body_v_ftps = VT_ftps * np.sin(beta_rad)
    v_body_w_ftps = VT_ftps * np.sin(alpha_rad) * np.cos(beta_rad)
    v_north_ft_per_s = VT_ftps * np.cos(theta_rad) * np.cos(psi_rad)
    v_east_ft_per_s = VT_ftps * np.cos(theta_rad) * np.sin(psi_rad)
    v_down_ft_per_s = -VT_ftps * np.sin(theta_rad)
    
    print(f"Data loaded. Simulating {nt_s} time steps...")

    # The main loop for visualization
    i = 0
    while True:
        try:
            # 1. Send velocity, attitude, and position
            # FDM connection to control surfaces failed
            fdm_tuple = (
                alt_m[i], phi_rad[i], theta_rad[i], psi_rad[i],
                v_body_u_ftps[i], v_body_v_ftps[i], v_body_w_ftps[i],
                alpha_rad[i], beta_rad[i], lat_rad[i], lon_rad[i],
                v_north_ft_per_s[i], v_east_ft_per_s[i], v_down_ft_per_s[i]
            )
            fdm_event_pipe.parent_send(fdm_tuple)
            
            # 2. Send control surface deflections (normalized)
            # Format must match the XML: "aileron,elevator,rudder\n"
            # Build a simple string and blast it to port 5505
            msg = f"{dela_norm[i]},{dele_norm[i]},{delr_norm[i]}\n"
            controls_sock.sendto(msg.encode(), controls_addr)
            
            # The real-time pacer so the visualization happens at the Octave simulation speed
            if i < nt_s - 1:
                dt = t_s[i + 1] - t_s[i]
                time.sleep(dt)
                i += 1
            else:
                print('\nVisualization completed.\n')
                break
                
        except KeyboardInterrupt:
            print("\nUser interrupted.")
            break
        except Exception as e:
            print(f"Error: {e}")
            break

    fdm_conn.stop()
    controls_sock.close()
    print("Connections closed.")